OEE Dashboard (Bahasa Indonesia) - Template
===========================================

Deskripsi singkat:
- Aplikasi Streamlit ini membaca data dari tab `database` di Google Sheet (melalui CSV export).
- Menampilkan tabel data, menghitung Availability/Performance/Quality/OEE, menampilkan tren, dan memberikan analisis otomatis sederhana (AI ringan).

Cara pakai (singkat):
1. Pastikan Google Sheet tujuan (tab 'database') bisa diakses publik (File → Share → Anyone with the link -> Viewer)
2. Dapatkan Sheet ID dari URL Google Sheet (bagian setelah /d/).
   Contoh: https://docs.google.com/spreadsheets/d/<SHEET_ID>/edit
3. Deploy di Streamlit Cloud:
   - Buat repository baru di GitHub.
   - Upload file `app.py`, `requirements.txt`, `README.txt` ke repo.
   - Buka https://share.streamlit.io → New app → pilih repo & file `app.py` → Deploy.
4. Setelah app berjalan, buka sidebar dan masukkan Sheet ID (atau CSV export URL) lalu klik Load.

Catatan penting:
- Aplikasi ini menggunakan metode CSV export untuk membaca Google Sheet. Pastikan tab 'database' tersedia dan memiliki header kolom yang konsisten.
- Untuk menyimpan data dari Sheet sumber (yang ada checkbox "Kirim Data"), gunakan Google Apps Script yang menyalin baris ke Sheet tujuan (database).
- Fitur "AI" di sini adalah analisis otomatis berbasis aturan/statistik sederhana (tanpa API eksternal). Jika ingin fitur chatbot berbahasa Indonesia yang menggunakan model besar (OpenAI/GCP), integrasi API diperlukan (akan ada biaya).

Kontak & bantuan:
- Jika ingin saya buatkan Apps Script juga atau versi yang memakai Service Account (untuk akses private Sheet), minta saja; saya bantu langkah demi langkah.
