import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from datetime import datetime

st.set_page_config(page_title="Dashboard OEE — PROMED", page_icon="📊", layout="wide")
st.title("📊 Dashboard OEE — PROMED")
st.markdown("Aplikasi ini membaca data dari **tab `database`** di Google Sheet tujuan (akses view publik atau gunakan CSV export).")

# Sidebar: input Sheet ID atau CSV URL
st.sidebar.header("Sumber Data Google Sheet")
st.sidebar.write("Masukkan Google Sheet ID atau URL export CSV.")
sheet_id = st.sidebar.text_input("Google Sheet ID (atau kosongkan jika pakai CSV URL)", value="")
csv_url_input = st.sidebar.text_input("Atau masukkan CSV export URL penuh (opsional)", value="")

if csv_url_input:
    csv_url = csv_url_input.strip()
elif sheet_id:
    csv_url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv"
else:
    st.warning("Silakan masukkan Google Sheet ID atau CSV export URL di sidebar untuk memuat data.")
    st.stop()

# Load data
@st.cache_data(ttl=300)
def load_data(csv_url):
    try:
        df = pd.read_csv(csv_url)
        return df
    except Exception as e:
        st.error("Gagal memuat data dari Google Sheet. Periksa URL / pastikan setelan 'Anyone with the link can view'.")
        st.exception(e)
        return None

df = load_data(csv_url)
if df is None:
    st.stop()

st.subheader("📋 Preview Data (tab 'database')")
st.dataframe(df.head(200), use_container_width=True)

# Deteksi kolom umum (Bahasa Indonesia / Inggris)
cols_lower = [c.strip().lower() for c in df.columns]

def find_col(candidates):
    for c in candidates:
        if c.lower() in cols_lower:
            return df.columns[cols_lower.index(c.lower())]
    return None

col_tanggal = find_col(["tanggal","date"])
col_shift = find_col(["shift"])
col_mesin = find_col(["mesin","machine","equipment"])
col_good = find_col(["good","ok","output","produksi"])
col_reject = find_col(["afkir","reject","ng","bad"])
col_planned = find_col(["jam kerja target","planned time","planned_minutes","planned"])
col_actual = find_col(["jam kerja aktual","actual time","actual","runtime","run_time"])
col_downtime = find_col(["downtime","jam berhenti","stop time"])
col_speed = find_col(["speed","ideal rate","ideal_rate","pcs/min"])

st.sidebar.header("Kolom terdeteksi otomatis")
st.sidebar.write({
    "Tanggal": col_tanggal,
    "Shift": col_shift,
    "Mesin": col_mesin,
    "Good (OK)": col_good,
    "Reject (AFKIR)": col_reject,
    "Planned (menit)": col_planned,
    "Actual (menit)": col_actual,
    "Downtime (menit)": col_downtime,
    "Speed (pcs/menit)": col_speed
})

# Konversi numeric dan tanggal
def to_num(col):
    return pd.to_numeric(df[col], errors='coerce') if col else pd.Series([np.nan]*len(df))

data = df.copy()
data['_good'] = to_num(col_good)
data['_reject'] = to_num(col_reject)
data['_total'] = data['_good'].fillna(0) + data['_reject'].fillna(0)

if col_planned:
    data['_planned'] = to_num(col_planned)
else:
    data['_planned'] = np.nan

if col_actual:
    data['_actual'] = to_num(col_actual)
else:
    if col_planned and col_downtime:
        data['_actual'] = data['_planned'] - to_num(col_downtime)
    else:
        data['_actual'] = np.nan

data['_downtime'] = to_num(col_downtime)
if col_speed:
    data['_ideal_rate'] = to_num(col_speed)
else:
    data['_ideal_rate'] = np.nan

# Compute metrics per row
def compute_row(r):
    planned = r.get('_planned', np.nan)
    actual = r.get('_actual', np.nan)
    downtime = r.get('_downtime', np.nan)
    good = r.get('_good', np.nan)
    total = r.get('_total', np.nan)
    ideal = r.get('_ideal_rate', np.nan)

    availability = np.nan
    if pd.notna(planned) and planned!=0:
        if pd.notna(downtime):
            availability = max(0.0, (planned - downtime)/planned)
        elif pd.notna(actual):
            availability = actual/planned
    elif pd.notna(actual):
        availability = 1.0  # fallback

    performance = np.nan
    if pd.notna(ideal) and pd.notna(actual) and actual>0:
        ideal_count = ideal * actual
        if ideal_count>0:
            performance = total/ideal_count
    else:
        performance = np.nan

    quality = np.nan
    if pd.notna(good) and pd.notna(total) and total>0:
        quality = good/total

    oee = np.nan
    if pd.notna(availability) and pd.notna(performance) and pd.notna(quality):
        oee = availability * performance * quality

    return pd.Series({
        "Availability": availability,
        "Performance": performance,
        "Quality": quality,
        "OEE": oee
    })

metrics = data.apply(compute_row, axis=1)
data = pd.concat([data, metrics], axis=1)

# Tampilkan KPI ringkasan
st.subheader("📈 Ringkasan KPI")
k1, k2, k3, k4 = st.columns(4)
k1.metric("Availability (rata-rata)", f"{(data['Availability'].mean()*100 if data['Availability'].notna().any() else np.nan):.2f}%")
k2.metric("Performance (rata-rata)", f"{(data['Performance'].mean()*100 if data['Performance'].notna().any() else np.nan):.2f}%")
k3.metric("Quality (rata-rata)", f"{(data['Quality'].mean()*100 if data['Quality'].notna().any() else np.nan):.2f}%")
k4.metric("OEE (rata-rata)", f"{(data['OEE'].mean()*100 if data['OEE'].notna().any() else np.nan):.2f}%")

st.markdown("**Catatan:** Persentase dihitung bila data tersedia. Periksa kolom Planned/Actual/Good/Reject/Speed bila beberapa metrik bernilai N/A.")

# Filter dan tabel
st.sidebar.header("Filter")
mesin_list = data[col_mesin].unique().tolist() if col_mesin else []
mesin_sel = st.sidebar.selectbox("Pilih Mesin (All = semua)", options=["All"] + mesin_list)
if col_tanggal:
    try:
        data['__date'] = pd.to_datetime(data[col_tanggal], errors='coerce')
        min_d = data['__date'].min().date()
        max_d = data['__date'].max().date()
        dr = st.sidebar.date_input("Rentang tanggal", value=(min_d, max_d))
    except:
        dr = None
else:
    dr = None

df_view = data.copy()
if mesin_sel != "All" and col_mesin:
    df_view = df_view[df_view[col_mesin]==mesin_sel]
if dr and col_tanggal:
    start, end = dr
    df_view = df_view[(df_view['__date']>=pd.to_datetime(start)) & (df_view['__date']<=pd.to_datetime(end))]

st.subheader("🔎 Data terfilter & Perhitungan")
display_cols = list(df.columns)[:15] + ['_total','Availability','Performance','Quality','OEE']
st.dataframe(df_view[display_cols].reset_index(drop=True).head(500), use_container_width=True)

# Trend chart
st.subheader("📉 Tren OEE")
if col_tanggal:
    trend = df_view.groupby(df_view['__date'].dt.date).agg({
        'OEE':'mean',
        'Availability':'mean',
        'Performance':'mean',
        'Quality':'mean'
    }).reset_index().rename(columns={'__date':'Tanggal'})
    if trend['OEE'].notna().any():
        fig = px.line(trend, x='Tanggal', y=['OEE','Availability','Performance','Quality'], markers=True)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Belum ada nilai OEE yang lengkap, pastikan kolom Planned/Actual/Good/Reject/Speed tersedia.")
else:
    st.info("Kolom tanggal tidak terdeteksi, tren tidak dapat ditampilkan.")

# Analisis otomatis (AI ringan)
st.subheader("🧠 Analisis Otomatis")
analysis_texts = []
# 1. Perbandingan rata-rata OEE minggu ini vs minggu lalu (jika ada tanggal)
if col_tanggal:
    try:
        today = pd.to_datetime('today').normalize()
        df_view['week'] = df_view['__date'].dt.isocalendar().week
        current_week = today.isocalendar().week
        cur = df_view[df_view['week']==current_week]['OEE'].mean()
        prev = df_view[df_view['week']==(current_week-1)]['OEE'].mean()
        if pd.notna(cur) and pd.notna(prev):
            diff = (cur - prev)*100
            if diff>0:
                analysis_texts.append(f"OEE minggu ini naik {diff:.2f}% dibanding minggu lalu.")
            elif diff<0:
                analysis_texts.append(f"OEE minggu ini turun {abs(diff):.2f}% dibanding minggu lalu.")
            else:
                analysis_texts.append("OEE minggu ini tidak berubah dibanding minggu lalu.")
    except Exception:
        pass

# 2. Shift dengan OEE terendah
if col_shift and 'OEE' in df_view.columns:
    shift_oee = df_view.groupby(col_shift).agg({'OEE':'mean'}).reset_index().sort_values('OEE')
    if not shift_oee['OEE'].isna().all():
        lowest = shift_oee.iloc[0]
        analysis_texts.append(f"Shift dengan rata-rata OEE terendah: {lowest[0]} (OEE ≈ {lowest[1]*100:.2f}%).")

# 3. Mesin dengan downtime terbanyak (jika kolom downtime ada)
if col_downtime and col_mesin:
    down = df_view.groupby(col_mesin).agg({_col: 'sum' for _col in ['_downtime'] if '_downtime' in df_view.columns}).reset_index().sort_values('_downtime', ascending=False)
    if not down.empty and '_downtime' in down.columns:
        top = down.iloc[0]
        analysis_texts.append(f"Mesin dengan total downtime terbesar: {top[0]} ({top['_downtime']:.0f} menit).")

if analysis_texts:
    for t in analysis_texts:
        st.info(t)
else:
    st.info("Belum ada cukup data untuk analisis otomatis. Pastikan data tanggal, shift, dan OEE tersedia.")

st.markdown("---")
st.caption("Analisis otomatis dibuat dengan logika statistik sederhana (AI ringan). Untuk chatbot/assistant berbasis model besar, proses integrasi API diperlukan.")